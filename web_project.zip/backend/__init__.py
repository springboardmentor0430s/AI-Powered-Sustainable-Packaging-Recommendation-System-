"""Initialise the backend package.

This file makes the backend directory a Python package so that
relative imports (e.g. ``from . import prediction``) work correctly
when running the app via uvicorn.
"""
