from __future__ import annotations

import re
import os
import json
from typing import Any, Dict, List, Sequence, Optional

import requests

import pandas as pd

import prediction


class EcoPackAIChatbot:
    """
    Lightweight chatbot wrapper for EcoPackAI.

    - Must expose respond(question, history) -> str
    - Uses prediction.recommend(...) for recommendation-related requests
    - Uses prediction._materials_raw for quick material info browsing
    """

    def __init__(self) -> None:
        # Ensure models + materials are loaded once
        prediction.load_models()

        # IMPORTANT FIX:
        # prediction.py defines _materials_raw, not _materials_df.
        self._materials_df = prediction._materials_raw  # type: ignore[attr-defined]

        if self._materials_df is None or not isinstance(self._materials_df, pd.DataFrame):
            # Keep system functional even if materials didn't load for some reason
            self._materials_df = pd.DataFrame()

        # OpenAI configuration: read API key and model from environment variables.  These
        # values are optional; if no API key is supplied, the chatbot will fall back
        # to its built‑in rule‑based responses.  To enable OpenAI integration, set
        # the `OPENAI_API_KEY` environment variable.  You can optionally set
        # `OPENAI_MODEL` to override the default model (gpt-3.5-turbo).
        self._openai_api_key: Optional[str] = os.getenv("OPENAI_API_KEY")
        # Default to a modern chat model.  Users may override with OPENAI_MODEL.
        self._openai_model: str = os.getenv("OPENAI_MODEL", "gpt-3.5-turbo")

    def _openai_chat(self, question: str, history: Sequence[dict]) -> Optional[str]:
        """
        Send the user question and chat history to the OpenAI Chat Completion API
        and return a response.  If the API key is not configured or any error
        occurs, return None to signal that a fallback response should be used.

        This helper constructs a system prompt to inform the model about the
        domain (sustainable packaging) and includes conversation history to
        provide context.  It limits the number of prior messages to avoid
        excessively long prompts.  The API key is read from the environment
        variable `OPENAI_API_KEY` during class initialisation.

        :param question: The current user question
        :param history: A sequence of prior chat messages with roles 'user' or 'assistant'
        :return: The model's reply as a string, or None if no reply could be obtained
        """
        api_key = self._openai_api_key
        if not api_key:
            return None
        try:
            # Build messages list with a domain‑specific system prompt.  This
            # prompt instructs the model on its role and behaviour.  It is
            # augmented with per‑session user/company context when available.
            base_system_prompt = (
                "You are EcoPackAI Chatbot, an AI assistant specialised in sustainable "
                "packaging materials. You can answer general questions about packaging "
                "recommendations, sustainability metrics and explain concepts. For user "
                "questions that request a recommendation, remind them to use the recommender "
                "form or provide at least category, weight, fragility and budget details so "
                "that the system can generate a ranked list. If a question is unrelated to "
                "packaging or sustainability, reply politely that you are focused on packaging "
                "recommendations."
            )
            messages: List[Dict[str, str]] = [{"role": "system", "content": base_system_prompt}]

            # If user context is available via environment variables, inform the
            # model so it can tailor its responses to the specific user and
            # organisation.  This context is provided by the API layer.
            import os as _os
            user_email = _os.getenv("CHATBOT_CURRENT_USER_EMAIL") or ""
            company_name = _os.getenv("CHATBOT_CURRENT_COMPANY") or ""
            if user_email or company_name:
                context_msg = (
                    f"The current user is {user_email or 'an unknown user'}."
                    f" They work at {company_name or 'an unknown company'}."
                    " Please provide answers relevant to this user and organisation."
                )
                messages.append({"role": "system", "content": context_msg})
            # Include the last few messages from history to maintain context.  Limit to
            # the most recent 10 exchanges to avoid exceeding token limits.  History
            # entries provided by the frontend have keys 'role' and 'content'.
            # Convert roles to the expected values for the OpenAI API ('user' and 'assistant').
            if history:
                # Only include the last 10 messages
                for msg in history[-10:]:
                    role = str(msg.get("role") or "user").lower()
                    content = str(msg.get("content") or "").strip()
                    if not content:
                        continue
                    if role not in {"user", "assistant", "system"}:
                        role = "user"
                    messages.append({"role": role, "content": content})
            # Append the current user question
            messages.append({"role": "user", "content": question})

            # ---- Material context augmentation ----
            # Extract potential material search terms from the question.  Then
            # retrieve a concise snippet of the materials dataset relevant to
            # those terms.  This retrieval acts as a lightweight RAG step
            # allowing the model to answer specific material queries using the
            # information loaded from the prediction materials CSV.  The
            # number of rows and columns used is configurable via
            # OPENAI_MATERIAL_CONTEXT_ROWS and OPENAI_MATERIAL_CONTEXT_COLS.
            try:
                terms = self._extract_search_terms(question)
                material_context = self._build_material_context(terms)
                if material_context:
                    messages.append({"role": "system", "content": material_context})
            except Exception:
                # If anything fails, silently proceed without context
                pass
            # Prepare payload for OpenAI Chat API
            payload = {
                "model": self._openai_model,
                "messages": messages,
                "temperature": 0.7,
                "max_tokens": 500,
                "n": 1,
            }
            headers = {
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            }
            response = requests.post(
                "https://api.openai.com/v1/chat/completions",
                headers=headers,
                data=json.dumps(payload),
                timeout=15,
            )
            if response.status_code != 200:
                return None
            data = response.json()
            # Extract the assistant's reply
            choices = data.get("choices")
            if not choices:
                return None
            message = choices[0].get("message")
            if not message:
                return None
            content = message.get("content")
            if not content:
                return None
            return content.strip()
        except Exception:
            # Any error (network, JSON decoding, etc.) triggers fallback
            return None

    def _normalize_text(self, text: str) -> str:
        return re.sub(r"\s+", " ", (text or "")).strip().lower()

    def _is_reco_intent(self, q: str) -> bool:
        """
        Determine if the user is likely requesting a recommendation.  Expanded
        synonyms allow for more natural phrasing (e.g. "recommendation", "which
        material should I use", "best packaging", "eco friendly packaging", etc.).

        :param q: Normalised user question (lowercase, trimmed)
        :return: True if the question expresses an intent to recommend materials
        """
        # Expand the list of phrases that signal a recommendation intent.  This
        # list now includes natural variations like questions about the "best"
        # or "most eco-friendly" packaging, comparative phrases, and phrases
        # that implicitly request a suggestion without using the word "recommend".
        keywords = [
            "recommend",
            "recommendation",
            "suggest",
            "best material",
            "which material",
            "packaging material",
            "choose material",
            "what material",
            "use for packaging",
            "eco friendly packaging",
            "eco-friendly packaging",
            "best packaging",
            "best packaging material",
            "material should i use",
            "option has the lowest",
            "lowest co2",
            "lowest cost",
            "most cost effective",
            "most cost-effective",
            "most eco friendly",
            "most eco-friendly",
            "which option",
            "which packaging",
            "what packaging",
        ]
        return any(k in q for k in keywords)

    def _is_list_materials_intent(self, q: str) -> bool:
        """
        Determine if the user is asking to list available materials.  Accepts a
        wider range of phrasings (e.g. "what materials do you have", "show me
        materials", etc.) to improve comprehension.
        """
        keywords = [
            "list materials",
            "show materials",
            "available materials",
            "materials you have",
            "material types",
            "what materials",
            "which materials",
            "materials available",
        ]
        return any(k in q for k in keywords)

    def _format_material_list(self, limit: int = 20) -> str:
        df = self._materials_df
        if df.empty:
            return "I can’t access the materials list right now (materials table/CSV not loaded)."

        name_col = "MaterialName" if "MaterialName" in df.columns else None
        type_col = "MaterialType" if "MaterialType" in df.columns else None

        if not name_col and not type_col:
            return "Materials data is loaded, but it doesn’t include MaterialName/MaterialType columns."

        rows = []
        for _, row in df.head(limit).iterrows():
            name = str(row.get(name_col, "")).strip() if name_col else ""
            mtype = str(row.get(type_col, "")).strip() if type_col else ""
            if name and mtype:
                rows.append(f"- {name} ({mtype})")
            elif name:
                rows.append(f"- {name}")
            elif mtype:
                rows.append(f"- {mtype}")

        if not rows:
            return "No material entries found."

        suffix = "" if len(df) <= limit else f"\n\n(Showing {limit} of {len(df)} materials.)"
        return "Here are some materials I have:\n" + "\n".join(rows) + suffix

    def _extract_search_terms(self, question: str) -> List[str]:
        """
        Identify potential material search terms from the user's question.  This
        method extracts words or phrases that may correspond to material names
        or material types.  It uses a simple heuristic: split on common
        separators and select tokens with at least three alphanumeric
        characters.  Tokens are compared case-insensitively against the
        materials dataset to determine if they match any MaterialName or
        MaterialType values.  The returned list is unique and preserves the
        order of appearance in the question.

        :param question: Raw user question
        :return: A list of candidate search terms (case-sensitive to match DataFrame)
        """
        df = self._materials_df
        if df is None or df.empty:
            return []
        # Build sets of known material names/types in lowercase for quick lookup
        name_col = None
        type_col = None
        for c in ["MaterialName", "materialName", "name"]:
            if c in df.columns:
                name_col = c
                break
        for c in ["MaterialType", "materialType", "type"]:
            if c in df.columns:
                type_col = c
                break
        known_names: set[str] = set()
        known_types: set[str] = set()
        if name_col:
            known_names = {str(x).strip().lower() for x in df[name_col].dropna().unique()}
        if type_col:
            known_types = {str(x).strip().lower() for x in df[type_col].dropna().unique()}
        # Tokenise the question on whitespace and punctuation
        # Preserve hyphenated words (e.g. "eco-friendly")
        tokens = re.findall(r"[A-Za-z][A-Za-z0-9_\-]{2,}", question)
        seen: set[str] = set()
        terms: List[str] = []
        for tok in tokens:
            t_lower = tok.lower()
            if t_lower in seen:
                continue
            # If token matches known material name or type (or part thereof), add
            # it as a search term.  We allow partial matches (substring) to
            # capture queries like "plastic" matching "Recycled Plastic".
            matched = False
            for kn in known_names:
                if t_lower in kn:
                    terms.append(tok)
                    seen.add(t_lower)
                    matched = True
                    break
            if matched:
                continue
            for kt in known_types:
                if t_lower in kt:
                    terms.append(tok)
                    seen.add(t_lower)
                    break
        return terms

    def _build_material_context(self, terms: List[str]) -> Optional[str]:
        """
        Build a concise snippet of the materials dataset to provide context to
        the OpenAI model.  Given a list of search terms, this method selects
        relevant rows from the materials DataFrame and composes a few lines of
        human-readable information for each row.  The number of rows and
        columns included can be controlled via the environment variables
        OPENAI_MATERIAL_CONTEXT_ROWS and OPENAI_MATERIAL_CONTEXT_COLS.

        If no terms are provided, it will return None to avoid including
        irrelevant context.  When terms are provided but no matching rows are
        found, the method returns a general sample of materials up to the
        configured row limit.

        :param terms: Candidate search terms from the user question
        :return: A string containing material information, or None
        """
        df = self._materials_df
        if df is None or df.empty:
            return None
        import os as _os
        # Determine how many rows and which columns to include
        try:
            rows_limit = int(_os.getenv("OPENAI_MATERIAL_CONTEXT_ROWS", "3"))
            if rows_limit <= 0:
                return None
        except Exception:
            rows_limit = 3
        cols_env = _os.getenv("OPENAI_MATERIAL_CONTEXT_COLS", "")
        include_cols: List[str] = []
        if cols_env:
            for c in [x.strip() for x in cols_env.split(",") if x.strip()]:
                if c in df.columns:
                    include_cols.append(c)
        # Fallback default columns: choose some common and informative ones if
        # not explicitly configured
        if not include_cols:
            for candidate in [
                "MaterialName",
                "MaterialType",
                "StrengthRating",
                "MoistureBarrier",
                "OxygenBarrier",
                "CostPerKG_USD",
                "CO2_Emissions_KG_Per_Ton",
            ]:
                if candidate in df.columns:
                    include_cols.append(candidate)
        # Build mask for rows matching any of the search terms
        matched_df = pd.DataFrame()
        if terms:
            mask = None
            for term in terms:
                t_lower = term.lower()
                row_mask = None
                # Search across MaterialName and MaterialType columns
                if "MaterialName" in df.columns:
                    row_mask = df["MaterialName"].astype(str).str.lower().str.contains(t_lower, na=False)
                if "MaterialType" in df.columns:
                    m2 = df["MaterialType"].astype(str).str.lower().str.contains(t_lower, na=False)
                    row_mask = m2 if row_mask is None else (row_mask | m2)
                if row_mask is not None:
                    mask = row_mask if mask is None else (mask | row_mask)
            if mask is not None:
                matched_df = df[mask].copy()
        # If no matches found, optionally fall back to a sample of the dataset
        if matched_df.empty:
            # Without a search term, return no context to avoid noise
            if not terms:
                return None
            matched_df = df.copy()
        # Limit rows
        snippet = matched_df.head(rows_limit)[include_cols]
        # Compose lines
        lines: List[str] = []
        for _, row in snippet.iterrows():
            parts: List[str] = []
            for col in include_cols:
                val = row.get(col)
                if pd.isna(val):
                    continue
                # Simplify column name for readability
                label = col
                # Provide friendly names for common columns
                if col.lower().startswith("materialname"):
                    label = "Name"
                elif col.lower().startswith("materialtype"):
                    label = "Type"
                elif col.lower() == "strengthrating":
                    label = "Strength"
                elif col.lower() == "moisturebarrier":
                    label = "MoistureBarrier"
                elif col.lower() == "oxygenbarrier":
                    label = "OxygenBarrier"
                elif col.lower() in {"costperkg_usd", "costperkg_usd", "costperkg_usd"}:
                    label = "CostPerKG_USD"
                elif col.lower().startswith("co2"):
                    label = "CO2"
                parts.append(f"{label}: {val}")
            if parts:
                lines.append("; ".join(parts))
        if not lines:
            return None
        header = "Relevant materials information:"
        return header + "\n" + "\n".join(lines)

    def _try_parse_product_from_text(self, q: str) -> Optional[Dict[str, Any]]:
        """
        Very simple parser: if user writes something like:
          'recommend for category Food weight 2 fragility 7 budget 5 shipping 200'
        we'll attempt to extract values.
        This is optional; frontend usually calls /recommend directly.
        """
        # Defaults align with your ProductRequest schema
        product: Dict[str, Any] = {
            "productName": "Chat product",
            "category": "General",
            "weightKg": 1.0,
            "fragility": 5,
            "maxBudget": 10.0,
            "shippingDistance": 500.0,
            "moistureReq": 5,
            "oxygenSensitivity": 5,
            "preferredBiodegradable": 0,
            "preferredRecyclable": 0,
        }

        # Extract numeric fields if present
        def grab_float(pattern: str) -> Optional[float]:
            m = re.search(pattern, q, flags=re.IGNORECASE)
            return float(m.group(1)) if m else None

        def grab_int(pattern: str) -> Optional[int]:
            m = re.search(pattern, q, flags=re.IGNORECASE)
            return int(float(m.group(1))) if m else None

        w = grab_float(r"\bweight\s*[:=]?\s*(\d+(\.\d+)?)\b")
        if w is not None:
            product["weightKg"] = w

        f = grab_int(r"\bfragility\s*[:=]?\s*(\d+)\b")
        if f is not None:
            product["fragility"] = max(1, min(10, f))

        b = grab_float(r"\bbudget\s*[:=]?\s*(\d+(\.\d+)?)\b")
        if b is not None:
            product["maxBudget"] = b

        sd = grab_float(r"\bshipping\s*[:=]?\s*(\d+(\.\d+)?)\b")
        if sd is not None:
            product["shippingDistance"] = sd

        mr = grab_int(r"\bmoisture\s*[:=]?\s*(\d+)\b")
        if mr is not None:
            product["moistureReq"] = max(0, min(10, mr))

        ox = grab_int(r"\boxygen\s*[:=]?\s*(\d+)\b")
        if ox is not None:
            product["oxygenSensitivity"] = max(0, min(10, ox))

        # Category (single word or simple phrase)
        cm = re.search(r"\bcategory\s*[:=]?\s*([a-zA-Z][a-zA-Z0-9 _-]{0,40})", q)
        if cm:
            product["category"] = cm.group(1).strip()

        # If user didn’t provide at least one “strong” field, don’t attempt
        provided_any = any(
            k in q.lower()
            for k in ["weight", "fragility", "budget", "shipping", "category", "moisture", "oxygen"]
        )
        # Additional parsing: interpret 'low co2' as emphasising sustainability.
        q_lower = q.lower()
        if "low co2" in q_lower or "low carbon" in q_lower or "eco-friendly" in q_lower:
            # Set sustainability preferences to favour biodegradable/recyclable materials
            product["preferredBiodegradable"] = 1
            product["preferredRecyclable"] = 1
        if "recyclable" in q_lower:
            product["preferredRecyclable"] = 1
        if "biodegradable" in q_lower:
            product["preferredBiodegradable"] = 1
        # Recognise 'fragile' adjective to set high fragility
        if "fragile" in q_lower and "fragility" not in q_lower:
            product["fragility"] = 8
        # Recognise budget phrases like 'under $3' or 'under 3 dollars'
        m_budget = re.search(r"under\s*\$?\s*(\d+(\.\d+)?)", q_lower)
        if m_budget:
            product["maxBudget"] = float(m_budget.group(1))
        return product if provided_any else None

    def respond(self, question: str, history: Sequence[dict] = ()) -> str:
        q = self._normalize_text(question)

        if not q:
            return "Ask me about packaging material recommendations, or say 'list materials'."

        # ----- Extended small talk and FAQ -----
        # Friendly greetings
        for greet in ("hi", "hello", "hey"):  # handle simple salutations
            if q.startswith(greet):
                return (
                    "Hello! I can help you find sustainable packaging materials, explain our metrics, or "
                    "generate reports. Try asking for a recommendation or type 'help' for more options."
                )

        # Explain what various metrics mean
        if "cost efficiency" in q or ("cost" in q and "index" in q):
            return (
                "The cost efficiency index compares the predicted cost of each material against the others. "
                "Higher values indicate lower cost per unit relative to the full set of materials."
            )
        if "co2" in q and ("impact index" in q or "emissions" in q or "index" in q):
            return (
                "The CO₂ impact index compares the predicted carbon emissions of each material. "
                "Higher values indicate lower emissions per unit, so materials with a high CO₂ impact index "
                "are more environmentally friendly."
            )
        if "suitability score" in q or "ranking score" in q or ("suitability" in q and "score" in q):
            return (
                "The suitability score combines sustainability, cost efficiency and material constraints into a "
                "single 0–100 score. It weights CO₂ impact (50%), cost efficiency (35%) and risk penalties (15%). "
                "A higher suitability score indicates a better overall match."
            )

        # Explain cost savings and CO₂ reduction terms
        if "cost savings" in q or ("cost" in q and "savings" in q):
            return (
                "The cost savings metric on your dashboard compares the predicted costs of materials relative to "
                "the most expensive options. It reflects how much cheaper a material is compared with the worst "
                "case. Larger numbers mean greater potential savings."
            )
        if "co2 reduction" in q or ("carbon" in q and "reduction" in q):
            return (
                "CO₂ reduction indicates how much lower the predicted emissions are compared with the least "
                "sustainable materials. Higher percentages mean more environmentally friendly options."
            )

        # Questions about reports or dashboard
        if "report" in q or "pdf" in q or "excel" in q:
            return (
                "You can download your sustainability report from the Dashboard page in the application. "
                "Click on the PDF or Excel download buttons to generate a report summarizing your past recommendations."
            )
        if "dashboard" in q or "chart" in q or "metrics" in q:
            return (
                "The dashboard aggregates your recommendation history to show CO₂ reduction, cost savings and "
                "material usage trends. These charts update as you generate more recommendations."
            )

        # List materials
        if self._is_list_materials_intent(q):
            return self._format_material_list(limit=20)

        # ----- Contextual follow-up handling -----
        # If the current question does not explicitly express a recommendation intent
        # but the previous user message did, treat this as a continuation.  Merge
        # the parameters from the last recommendation request with any updated
        # values extracted from the current question.  This allows users to ask
        # follow‑up questions like "make it recyclable" or "lower the weight to 2kg"
        # without repeating all parameters.  The history parameter is expected to
        # contain a sequence of chat messages with 'role' and 'content'.
        if not self._is_reco_intent(q) and history:
            last_user_q: Optional[str] = None
            # Find the most recent user message in the history
            for msg in reversed(history):
                if isinstance(msg, dict) and msg.get("role") == "user":
                    last_user_q = self._normalize_text(str(msg.get("content") or ""))
                    break
            if last_user_q and self._is_reco_intent(last_user_q):
                prev_product = self._try_parse_product_from_text(last_user_q) or {}
                if prev_product:
                    # Extract any updated parameters from the current question
                    current_product = self._try_parse_product_from_text(question) or {}
                    merged = dict(prev_product)
                    for key, val in current_product.items():
                        # Skip overriding productName if it's just the default placeholder
                        if key == "productName" and val == "Chat product":
                            continue
                        merged[key] = val
                    try:
                        recs = prediction.recommend(merged)
                        if recs:
                            lines = ["Updated recommendations:"]
                            for i, r in enumerate(recs[:5], start=1):
                                name = r.get("materialName", r.get("MaterialName", r.get("MaterialType", "Material")))
                                score = r.get("suitabilityScore", r.get("rankingScore", ""))
                                cost = r.get("predictedCost", r.get("predictedCostUSD", r.get("predicted_cost_unit_usd", "")))
                                co2 = r.get("predictedCO2", r.get("predictedCO2KG", r.get("predicted_co2_unit_kg", "")))
                                reason = r.get("reason", r.get("recommendationReason", ""))
                                parts = [f"{i}) {name}"]
                                if score != "":
                                    try:
                                        parts.append(f"score {float(score):.0f}/100")
                                    except Exception:
                                        parts.append(f"score {score}")
                                if cost != "":
                                    try:
                                        parts.append(f"cost {float(cost):.3f} USD/unit")
                                    except Exception:
                                        parts.append(f"cost {cost} USD/unit")
                                if co2 != "":
                                    try:
                                        parts.append(f"CO₂ {float(co2):.3f} kg/unit")
                                    except Exception:
                                        parts.append(f"CO₂ {co2} kg/unit")
                                line = " — ".join([parts[0], ", ".join(parts[1:])]) if len(parts) > 1 else parts[0]
                                if reason:
                                    line += f"\n   Reason: {reason}"
                                lines.append(line)
                            return "\n".join(lines)
                    except Exception:
                        # In case of any error, fall back to default handling
                        pass

        # Recommendation intent (best effort)
        if self._is_reco_intent(q):
            product = self._try_parse_product_from_text(question)
            if not product:
                return (
                    "To recommend materials, tell me at least:\n"
                    "- category (e.g., Food)\n"
                    "- weight (kg)\n"
                    "- fragility (1–10)\n"
                    "- max budget (USD/unit)\n\n"
                    "Example: 'recommend for category Food weight 2 fragility 7 budget 5 shipping 200'."
                )

            try:
                recs = prediction.recommend(product)
                if not recs:
                    return "I couldn’t find any suitable materials with those constraints."

                lines = ["Top recommendations:"]
                for i, r in enumerate(recs[:5], start=1):
                    name = r.get("materialName", "Material")
                    score = r.get("suitabilityScore", r.get("rankingScore", ""))
                    cost = r.get("predictedCost", "")
                    co2 = r.get("predictedCO2", "")
                    reason = r.get("reason", r.get("recommendationReason", ""))

                    parts = [f"{i}) {name}"]
                    if score != "":
                        parts.append(f"score {float(score):.0f}/100")
                    if cost != "":
                        parts.append(f"cost {float(cost):.3f} USD/unit")
                    if co2 != "":
                        parts.append(f"CO₂ {float(co2):.3f} kg/unit")

                    line = " — ".join([parts[0], ", ".join(parts[1:])]) if len(parts) > 1 else parts[0]
                    if reason:
                        line += f"\n   Reason: {reason}"
                    lines.append(line)

                return "\n".join(lines)
            except Exception as e:
                return f"Sorry — I couldn’t generate recommendations due to an internal error: {e}"

        # Generic help
        if "help" in q or "how" in q:
            return (
                "You can ask me to:\n"
                "- recommend a packaging material (include category, weight, fragility, budget)\n"
                "- list available materials\n"
                "- explain what cost/CO₂ predictions mean\n"
            )

        # Default response: attempt to use OpenAI for a more natural reply.  If
        # the OpenAI integration is configured (via OPENAI_API_KEY) and returns
        # a response, use that.  Otherwise, fall back to a canned message.
        openai_answer = self._openai_chat(question, history)
        if openai_answer:
            return openai_answer
        # Construct a generic fallback response.  If user/company context is
        # available in the environment, include it to personalise the
        # message without cluttering the core guidance.
        msg = (
            "I can help with material recommendations and sustainability questions.\n"
            "Try: 'list materials' or 'recommend for category Food weight 2 fragility 7 budget 5 shipping 200'."
        )
        import os as _os
        user_email = _os.getenv("CHATBOT_CURRENT_USER_EMAIL") or ""
        company_name = _os.getenv("CHATBOT_CURRENT_COMPANY") or ""
        if user_email or company_name:
            msg += "\n"
            msg += f"This guidance is tailored for {user_email or 'you'} at {company_name or 'your company'}."
        return msg


# Module-level singleton used by main.py: `from chatbot import chatbot`
chatbot = EcoPackAIChatbot()
